<?php
	for($a=1;$a<10;$a++)
	{
		echo $a;
	}
?>
<div style="background-color:red;height:200;width:200; padding:20"><h2>Hii This is Aakash</h2></div>